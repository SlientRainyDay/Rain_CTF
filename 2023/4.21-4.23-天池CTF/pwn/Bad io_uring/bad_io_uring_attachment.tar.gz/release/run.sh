exec timeout -k1 120 stdbuf -i0 -o0 -e0 \
qemu-system-x86_64 \
	-m 256M \
	-cpu qemu64,+smep,+smap \
	-smp 2 \
	-kernel bzImage \
	-initrd rootfs.cpio.gz \
	-nographic \
	-snapshot \
	-append "oops=panic panic=1 kaslr console=ttyS0" \
	-hda flag.img \
	-monitor /dev/null
