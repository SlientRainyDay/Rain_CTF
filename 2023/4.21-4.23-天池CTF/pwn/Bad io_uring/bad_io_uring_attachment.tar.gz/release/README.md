I heard this is a CVE? Oh, bad io_uring! Let's fix it! We should be safe now! lol


## Environment
```bash
cat /etc/issue
Ubuntu 22.04.2 LTS \n \l

cc --version
cc (Ubuntu 11.3.0-1ubuntu1~22.04) 11.3.0
Copyright (C) 2021 Free Software Foundation, Inc.
This is free software; see the source for copying conditions.  There is NO
warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

uname -a
Linux 5.19.0-38-generic #39~22.04.1-Ubuntu SMP PREEMPT_DYNAMIC Fri Mar 17 21:16:15 UTC 2 x86_64 x86_64 x86_64 GNU/Linux
```

## Setup
```bash
wget https://cdn.kernel.org/pub/linux/kernel/v5.x/linux-5.10.116.tar.xz
wget https://git.kernel.org/pub/scm/linux/kernel/git/stable/linux-stable-rc.git/patch/?h=linux-5.10.y&id=29f077d070519a88a793fbc70f1e6484dc6d9e35 -O cve.patch
tar -xf linux-5.10.116.tar.xz

cd linux-5.10.116
patch -p1 < ../cve.patch
make defconfig
./scripts/config -e CONFIG_CHECKPOINT_RESTORE -d CONFIG_UNIX
echo | make oldconfig
make -j32
```
