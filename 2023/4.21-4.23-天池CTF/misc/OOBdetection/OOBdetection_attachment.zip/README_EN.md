# OOBdetection

## Description

SC is a newly defined imperative language with syntax and semantics similar to C. Its syntax is described using EBNF as follows:


```
Prog := DefList ArrList;

DefList := { varDef ';' }

ArrList := { arrayExpr ';' }

Typename := 'int'      
          ;
          
varDef   := Typename Id {'[' expr ']'}   
          | Typename Id '=' DigitSequence                       
          ;
        
arrayUnit := Id '[' expr ']' {'[' expr ']'}
           ;
           
arrayExpr := Id AssignmentOperator arrayUnit
           | Id AssignmentOperator expr
           | arrayUnit AssignmentOperator expr
           ;
          
expr := arrayUnit op expr
       | Id op expr    
       | DigitSequence op expr 
       | arrayUnit                         
       | Id                        
       | DigitSequence                    
       ;

op := '/' |'*' | '+' | '-'
     ;

AssignmentOperator := '='
                    ;

Id := IdNondigit { IdNondigit | digit }
     ;

DigitSequence := nonzero-digit { digit }
               ;

nonzero-digit := '1' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' ;

digit := '0' |  '1' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' ;

```

There `IdNondigit` means `[a-zA-Z_]`.

The server will give multiple SC programs, please check whether there is an array index value out of bounds in the SC programs given by the server **within 120 seconds** (**Uninitialized variable value is unknown**).

If there is an array out-of-bounds, send `oob`, if the program is safe, send `safe`.



If the program has an array out-of-bounds vulnerability, send `oob`; if there is no array out-of-bounds vulnerability, send `safe`; if the program can not be determined or has other errors occur, send `unknown`.



### Attachment: logic of hash script

```python
def proof_of_work():
    s = os.urandom(10)
    digest = sha256(s).hexdigest()
    my_print("sha256(XXX + {0}) == {1}".format(s[3:].hex(),digest))
    my_print("Give me XXX in hex: ")
    x = read_str()
    if len(x) != 6 or x != s[:3].hex():
        my_print("Wrong!")
        return False
    return True

def PoW():
    if not proof_of_work():
        sys.exit(-1)
```

