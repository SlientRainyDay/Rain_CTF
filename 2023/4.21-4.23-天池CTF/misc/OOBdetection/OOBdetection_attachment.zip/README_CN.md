# OOBdetection

## 题目说明

SC是本题新定义的一种语法和语义类似C语言的命令式语言，其语法使用EBNF描述如下：


```
Prog := DefList ArrList;

DefList := { varDef ';' }

ArrList := { arrayExpr ';' }

Typename := 'int'      
          ;
          
varDef   := Typename Id {'[' expr ']'}   
          | Typename Id '=' DigitSequence                       
          ;
        
arrayUnit := Id '[' expr ']' {'[' expr ']'}
           ;
           
arrayExpr := Id AssignmentOperator arrayUnit
           | Id AssignmentOperator expr
           | arrayUnit AssignmentOperator expr
           ;
          
expr := arrayUnit op expr
       | Id op expr    
       | DigitSequence op expr 
       | arrayUnit                         
       | Id                        
       | DigitSequence                    
       ;

op := '/' |'*' | '+' | '-'
     ;

AssignmentOperator := '='
                    ;

Id := IdNondigit { IdNondigit | digit }
     ;

DigitSequence := nonzero-digit { digit }
               ;

nonzero-digit := '1' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' ;

digit := '0' |  '1' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' ;

```

其中`IdNondigit`表示`[a-zA-Z_]`。

服务器将给出多组SC的程序，请在**120秒内**检测服务器给出的SC程序中是否存在数组索引值越界的情况。(**未初始化的变量值未知**)

如果程序存在数组越界，发送`oob`；如果不存在数组越界，发送`safe`；如果无法判断或出现其他错误，发送`unknown`



### 附：hash验证逻辑

```python
def proof_of_work():
    s = os.urandom(10)
    digest = sha256(s).hexdigest()
    my_print("sha256(XXX + {0}) == {1}".format(s[3:].hex(),digest))
    my_print("Give me XXX in hex: ")
    x = read_str()
    if len(x) != 6 or x != s[:3].hex():
        my_print("Wrong!")
        return False
    return True

def PoW():
    if not proof_of_work():
        sys.exit(-1)
```

