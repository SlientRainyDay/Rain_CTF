#!/bin/bash

cd /home/ctf/
timeout 180 ./app