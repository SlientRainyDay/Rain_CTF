from flask import Flask, render_template, request
import base64, subprocess

app = Flask(__name__)

def sandbox(payload): 
    if len(payload) > 0x400:
        return b'Too long T_T'
    
    try:
        to_feed = base64.b64decode(payload)
    except:
        return b'Failed to decode base64 T_T'

    try:
        p = subprocess.Popen(['./box'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return p.communicate(input = to_feed, timeout=5)[0]
    except:
        return b'Error in testing your payload T_T'

@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        payload = request.form['payload']
        result = base64.b64encode(sandbox(payload)).decode()
        return render_template('result.html', result=result)
    return render_template('index.html')

if __name__ == '__main__':
    app.run(host = '0.0.0.0', port=1400)
