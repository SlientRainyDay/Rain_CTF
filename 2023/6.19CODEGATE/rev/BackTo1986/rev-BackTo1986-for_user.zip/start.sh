qemu-system-x86_64 -kernel ./bzImage -initrd ./initramfs.cpio.gz -vga std --append "console=ttyS0 console=tty0" 
