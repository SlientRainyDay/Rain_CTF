# sage
from sage.all import *
from Crypto.Util.number import getPrime,getStrongPrime, isPrime, bytes_to_long
from secret import r,g
from secret import flag

assert r.bit_length() == 512 and isPrime(r)
FLAG = bytes_to_long(flag)

def gen_DH_key(g,r):
    x = randint(2,r-1)
    return x, pow(g,x,r)

def gen_RSA_parameters(g,r):
    main_key = gen_DH_key(g,r)
    sub_key = gen_DH_key(g,r)
    x, X = main_key
    w, W = sub_key
    print(f"[+] Public DH Keys { X = }")
    print(f"[+] Public DH Keys { W = }")
    while True:
        c, C = gen_DH_key(g,r)
        t1 = randint(0,1)
        t2 = randint(0,1)
        p = ZZ(C * W^t1 * pow(X, c, r) % r)
        if not is_prime(p):
            continue
        q = ZZ(pow(W, -t2, r) * pow(X, -c, r) % r)
        if not is_prime(q):
            print(f"[+] Try {c ,C}")
            continue
        return p,q
    
p, q = gen_RSA_parameters(g,r)
n = p*q
e = 65537
c = pow(FLAG,e,n)
print(f"{ c = }")
print(f"{ n = }")