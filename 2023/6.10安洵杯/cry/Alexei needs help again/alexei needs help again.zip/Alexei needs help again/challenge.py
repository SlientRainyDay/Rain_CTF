from random import *
import gmpy2 as gp 
from Crypto.Util.number import *
from Crypto.Cipher import AES 
from hashlib import md5 
from binascii import * 
from secret import flag 
n = 666
M = getrandbits(512) 
m = getrandbits(512)
seq = [getrandbits(32) for _ in range(n)] 
def cseq(i):
    ct = 0
    for j in seq:
        if i%j == 0: 
            ct+=1 
    return ct 

def homework(i):
    if i == 1: return 1 
    if i == 2: return 1 
    else: return (homework(i-2)+homework(i-1)+cseq(i-1) )%M # If u want mod, come and get it!
ans = homework(m) 

k = unhexlify(md5(str(ans).encode()).hexdigest())
aes = AES.new(k,AES.MODE_ECB)
data = flag + (16-len(flag)%16)*b"\x00"
ct = hexlify(aes.encrypt(data)) 
print(ct)
print(seq) 



